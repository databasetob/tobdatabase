# 🍽️ Taste of Baku — Business Manager

Full business management app for Taste of Baku catering (Dubai delivery).

## What's Included

- **📊 Dashboard** — Live stats: total orders, gross/net revenue, P&L, low stock alerts
- **🧾 Orders** — All 65 orders pre-loaded, filter by app/restaurant, add new orders, edit/delete
- **🍳 Kitchen Needs** — Track items to buy (Lazimli eşyalar), mark as bought, add photos
- **📦 Stock** — Kitchen inventory with photos, low-stock alerts, qty tracking
- **💳 Bank & Expenses** — All 28 transactions pre-loaded, filter income/expense
- **🗂️ Receipts** — Upload receipt photos, categorize
- **📈 Profit & Loss** — Full financial breakdown by app, by category, by day
- **⚙️ Delivery %** — Set commission rates per app (auto-calculates net earnings)

## How to Deploy on GitHub Pages (FREE)

1. Create a new GitHub repo (e.g. `tob-business`)
2. Upload `index.html` to the repo
3. Go to **Settings → Pages → Source → main branch**
4. Your app will be live at: `https://yourusername.github.io/tob-business`

## Data Storage

All data is saved in **browser localStorage** — no server needed, completely free.

To back up: go to Settings → Export JSON  
To restore: Settings → Import JSON

## Delivery Commission Rates (current defaults)
- Talabat: 32%
- Deliveroo: 30%  
- Careem: 25%
- Keeta: 30%
- Noon: 25%
- WhatsApp: 0%

Update these anytime in the Settings page and all calculations update instantly.
